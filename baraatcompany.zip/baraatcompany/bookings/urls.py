from django.urls import path
from .views import index, about #signup
from . import views




urlpatterns = [
    path('', index),
    path('about/', views.about),
    path('venues/', views.venues),
    path('vendors/', views.vendors),
    path('photos/', views.photos),
    path('testimonials/', views.testimonials),
    path('blog/', views.blog),
    path('profile/', views.profile),
    path('signup/', views.user_signup),
    path('login/', views.user_login),
    path('logout/', views.user_logout),
    #path('signup', signup)
]