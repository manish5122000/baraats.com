from django.shortcuts import render, HttpResponseRedirect
from .forms import SignupForm, LoginForm
from django.http import HttpResponse
from.models.vendors import Vendor
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from bookings.models import vendors
from .forms import ImageForm
from bookings.models.vendors import Vendor
from .admin import AdminVendor

# Create your views here.

#Index 
def index(request):
    form = Vendor.objects.all()
    return render(request, 'index.html',{'form':form})

#About 
def about(request):
    return render(request, 'about.html')

#venue 
def venues(request):
    return render(request, 'venues.html' )

#vendors 
def vendors(request):
    return render(request, 'vendors.html' )

#Photos 
def photos(request):
    form = ImageForm()
    return render(request, 'photos.html' ,{'form':form})

#testimonials 
def testimonials(request):
    return render(request, 'testimonials.html')

#Blog 
def blog(request):
    return render(request, 'blog.html')

#profile 
def profile(request):
    if request.user.is_authenticated:
        posts =Vendor.objects.all()
        return render(request, 'profile.html',{'posts':posts})
    else:
        return HttpResponseRedirect('/')

#logout
def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/')

#signup
def user_signup(request):
    if request.method == "POST":
        form = SignupForm(request.POST)
        if form.is_valid():
            messages.success(request, 'SignedUp Form Successfully!')
            form.save()
    else:
        form = SignupForm()
    return render(request, 'signup.html',{'form':form})

#login
def user_login(request):
    if not request.user.is_authenticated:
        if request.method == "POST":
            form = LoginForm(request=request, data=request.POST)
            if form.is_valid():
                uname = form.cleaned_data['username']
                upass = form.cleaned_data['password']
                user = authenticate(username=uname, password=upass)
                if user is not None:
                    login(request, user)
                    messages.success(request, 'Logged in Successfully!')
                    return HttpResponseRedirect('/profile/')
        else:
            form = LoginForm()
        return render(request, 'login.html',{'form':form})
    else:
        return HttpResponseRedirect('/profile/')



