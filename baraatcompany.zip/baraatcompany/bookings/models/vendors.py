from django.db import models
from .category import Category


class Vendor(models.Model):
    brandname = models.CharField(max_length=100)
    price = models.IntegerField(default=0)
    category = models.ForeignKey(Category , on_delete=models.CASCADE, default=1)
    description = models.CharField(max_length=200,default='')
    
    photo = models.ImageField(upload_to='vendors')  
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.brandname

   