from django.contrib import admin
from .models.vendors import Vendor
from .models.category import Category

class AdminVendor(admin.ModelAdmin):
    list_display = ['brandname' , 'price','category','date','photo']

class AdminCategory(admin.ModelAdmin):
    list_display = ['name']


# Register your models here.
admin.site.register(Vendor , AdminVendor)
admin.site.register(Category , AdminCategory)


